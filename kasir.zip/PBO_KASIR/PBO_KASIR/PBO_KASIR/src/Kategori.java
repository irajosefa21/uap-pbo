public class Kategori {
    private  String nama_kategori;

    public String getProduk(){
        return this.nama_kategori;
    }
}
