public interface ProductCounter {
    public double TAX = 0.11;
    public double hitungJumlahProduk();
    public double hitungHargaTotal();

}
